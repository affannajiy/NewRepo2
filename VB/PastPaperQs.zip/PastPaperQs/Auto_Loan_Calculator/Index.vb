﻿Public Class Index
    'Zess Coffee House
    Private Sub btnKopiSusu_Click(sender As Object, e As EventArgs) Handles btnKopiSusu.Click
        ZessCoffeeHouse.Show()
    End Sub

    'Auto Loan Calculator
    Private Sub btnLoan_Click(sender As Object, e As EventArgs) Handles btnLoan.Click
        AutoLoanCalc.Show()
    End Sub

    'SRC Election
    Private Sub btnSRC_Click(sender As Object, e As EventArgs) Handles btnSRC.Click
        SRC_Election.Show()
    End Sub

    'Staff Salary System
    Private Sub btnSalarySystem_Click(sender As Object, e As EventArgs) Handles btnSalarySystem.Click
        Staff_Salary_System.Show()
    End Sub

    'Pro Power Plant
    Private Sub btnPowerPlant_Click(sender As Object, e As EventArgs) Handles btnPowerPlant.Click
        ProPowerPlant.Show()
    End Sub

    'CGPA Button
    Private Sub btnCGPA_Click(sender As Object, e As EventArgs) Handles btnCGPA.Click
        CGPA_Calculator.Show()
    End Sub

    'Rainfall Reading System
    Private Sub btnRainfall_Click(sender As Object, e As EventArgs) Handles btnRainfall.Click
        Rainfall_Reading_System.Show()
    End Sub
End Class